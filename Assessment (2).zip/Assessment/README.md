# Memory Extraction & Personality Engine

A modular NLP system that extracts structured memory from user chat messages and transforms responses using different personality styles.

## 🎯 Project Overview

This project demonstrates:
- **Memory Extraction**: Parses 30 chat messages to extract user preferences, emotional patterns, and personal facts
- **Personality Engine**: Rewrites responses in three distinct styles (Calm Mentor, Witty Friend, Therapist)
- **Structured Output**: Exports extracted memory in JSON format

## 📁 Project Structure

```
Assessment/
├── messages.py              # 30 sample chat messages
├── memory_extractor.py      # Memory extraction logic
├── personality_engine.py   # Personality transformation engine
├── app.py                  # Main demo runner
├── requirements.txt        # Python dependencies
└── README.md              # This file
```

## 🚀 Quick Start

### Prerequisites

- Python 3.7 or higher
- No external dependencies required (uses only standard library)

### Installation

1. Clone or download this repository
2. Navigate to the project directory:
   ```bash
   cd Assessment
   ```

### Running the Demo

Simply run the main application:

```bash
python app.py
```

This will:
1. Load 30 sample chat messages
2. Extract structured memory (preferences, emotions, personal facts)
3. Display extracted memory in readable format
4. Output memory as JSON
5. Demonstrate personality transformations (before & after)

## 📊 What Gets Extracted

### 1. Personal Facts
- Name
- City/Location
- Job role and company
- Birthday
- Age
- Allergies
- Dietary preferences

### 2. Preferences
- **Likes**: Things the user enjoys (food, activities, hobbies)
- **Dislikes**: Things the user doesn't like
- **Favorites**: Favorite items, colors, authors, etc.

### 3. Emotional Patterns
- Emotion counts (happy, sad, anxious, frustrated, calm)
- Dominant emotion across all messages
- Total number of emotional messages

## 🎭 Personality Styles

The Personality Engine transforms generic responses into three distinct styles:

### 🧘 Calm Mentor
- Supportive and encouraging
- Offers wisdom and guidance
- Measured, calm tone
- Example: "I understand where you're coming from, and I'd like to share some perspective..."

### 😄 Witty Friend
- Playful and humorous
- Casual and friendly
- Uses jokes and light-hearted comments
- Example: "Hey Sarah! So here's the thing..."

### 💬 Therapist Style
- Empathetic and understanding
- Reflective and non-judgmental
- Validates feelings
- Example: "I hear you, Sarah. Let's explore this together..."

## 📝 Example Output

### Extracted Memory (JSON)

```json
{
  "personal_facts": {
    "name": "Sarah",
    "city": "New York",
    "location": "Brooklyn",
    "job_role": "software engineer",
    "company": "Google",
    "birthday": "March 15th, 1992",
    "age": 33,
    "allergies": ["peanuts"],
    "dietary_preferences": ["vegetarian"]
  },
  "preferences": {
    "likes": [
      "italian food",
      "reading science fiction novels",
      "playing video games",
      "hiking on weekends",
      "listening to jazz music"
    ],
    "dislikes": [
      "horror movies",
      "waking up early",
      "crowded places",
      "doing laundry",
      "spicy food"
    ],
    "favorites": [
      "blue",
      "isaac asimov",
      "green tea"
    ]
  },
  "emotional_patterns": {
    "emotion_counts": {
      "happy": 3,
      "anxious": 3,
      "sad": 1,
      "frustrated": 1,
      "calm": 1
    },
    "dominant_emotion": "happy",
    "total_emotional_messages": 9
  }
}
```

### Before & After Example

**Before (Generic Response):**
```
I understand you're feeling stressed about your upcoming deadline. 
You should break down your project into smaller tasks and prioritize them.
```

**After (Calm Mentor Style):**
```
I understand where you're coming from, and I'd like to share some perspective.

I understand you're feeling stressed about your upcoming deadline. 
You might consider breaking down your project into smaller tasks and prioritize them.

Remember, progress takes time, and you're doing great.
```

**After (Witty Friend Style):**
```
Hey Sarah! So here's the thing...

I totally get it you're feeling stressed about your upcoming deadline. 
You could totally break down your project into smaller tasks and prioritize them.

Hope that helps! You've got this! 💪
```

**After (Therapist Style):**
```
I hear you, Sarah. Let's explore this together.

It seems like you're feeling stressed about your upcoming deadline. 
You might find it helpful to break down your project into smaller tasks and prioritize them.

How does that feel to you?

There's no right or wrong answer here. What matters is what feels authentic to you.
```

## 🔧 Module Details

### `memory_extractor.py`
- `MemoryExtractor` class for extracting structured memory
- Methods: `extract_personal_facts()`, `extract_preferences()`, `extract_emotions()`
- Uses regex patterns and keyword matching for extraction
- Outputs structured JSON format

### `personality_engine.py`
- `PersonalityEngine` class for response transformation
- Methods: `calm_mentor_style()`, `witty_friend_style()`, `therapist_style()`
- Uses user memory for personalization (e.g., using the user's name)
- `demonstrate_improvement()` shows before/after comparisons

### `messages.py`
- Contains 30 diverse sample chat messages
- Covers various topics: preferences, emotions, personal information
- Easy to replace with real chat data

### `app.py`
- Main demo runner
- Orchestrates memory extraction and personality demonstration
- Provides formatted console output

## 🎓 Key Features

✅ **Modular Design**: Clean separation of concerns  
✅ **Structured Extraction**: Pattern-based extraction with regex  
✅ **Multiple Personalities**: Three distinct response styles  
✅ **Memory Integration**: Uses extracted memory for personalization  
✅ **JSON Output**: Structured data export  
✅ **Well Commented**: Clear code documentation  

## 🔮 Future Enhancements

Potential improvements:
- Add NLP libraries (NLTK, spaCy) for better extraction
- Machine learning models for emotion detection
- More personality styles
- Web interface (Streamlit/Flask)
- Database storage for memory
- Real-time chat integration

## 📄 License

This project is created for assessment purposes.

## 👤 Author

Built as part of an NLP and Conversational AI assessment.

---

**Note**: This project uses only Python standard library modules. No external dependencies are required to run the basic demo.

#   c h a t - p e r s o n a l i t y - e n g i n e  
 